/* Serveur Agence Mitantsoa : code de confirmation, demandes, dossiers, registre Excel */
require("dotenv").config();
const express=require("express"),multer=require("multer"),cors=require("cors"),helmet=require("helmet"),
 rateLimit=require("express-rate-limit"),nodemailer=require("nodemailer"),ExcelJS=require("exceljs"),
 crypto=require("crypto"),fs=require("fs"),path=require("path");
const {PORT=3000,HOST="127.0.0.1",ALLOWED_ORIGIN,MODE_TEST="true",ADMIN_USER,ADMIN_PASS,NOTIF_EMAIL,
 SMTP_HOST,SMTP_PORT=587,SMTP_USER,SMTP_PASS,MAIL_FROM,BREVO_API_KEY,SMS_SENDER="Mitantsoa"}=process.env;

const DATA=path.join(__dirname,"data"),REG=path.join(DATA,"registre.jsonl");
fs.mkdirSync(path.join(DATA,"dossiers"),{recursive:true});
const app=express();app.set("trust proxy",1);app.use(helmet());
app.use(cors({origin:ALLOWED_ORIGIN?ALLOWED_ORIGIN.split(",").map(s=>s.trim()):false}));
app.use(express.json({limit:"2mb"}));
const lim=n=>rateLimit({windowMs:15*60*1000,max:n,standardHeaders:true,legacyHeaders:false});

/* ---------- Outils ---------- */
const sha=s=>crypto.createHash("sha256").update(s).digest("hex");
const gen=()=>{const a="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";return[...crypto.randomBytes(8)].map(b=>a[b%a.length]).join("")};
const phone=s=>{s=String(s).replace(/[\s.\-()]/g,"");if(s.startsWith("+"))return s.slice(1);if(s.startsWith("00"))return s.slice(2);
 if(/^0(692|693)/.test(s))return"262"+s.slice(1);if(s.startsWith("0"))return"33"+s.slice(1);return s};
const norm=d=>String(d).includes("@")?String(d).trim().toLowerCase():phone(d);
const tr=SMTP_HOST?nodemailer.createTransport({host:SMTP_HOST,port:+SMTP_PORT,secure:+SMTP_PORT==465,auth:{user:SMTP_USER,pass:SMTP_PASS}}):null;
const mail=(to,subject,text)=>{if(!tr)throw new Error("SMTP non configuré");return tr.sendMail({from:MAIL_FROM||SMTP_USER,to,subject,text})};
const sms=async(num,content)=>{if(!BREVO_API_KEY)throw new Error("SMS non configuré");
 const r=await fetch("https://api.brevo.com/v3/transactionalSMS/sms",{method:"POST",headers:{"api-key":BREVO_API_KEY,"content-type":"application/json"},
  body:JSON.stringify({sender:SMS_SENDER,recipient:num,content,type:"transactional"})});
 if(!r.ok)throw new Error("SMS HTTP "+r.status)};

/* ---------- 1. Code de confirmation (8 caractères) ---------- */
const otps=new Map(),verified=new Map();
app.post("/envoi",lim(15),async(req,res)=>{
 const {action,canal,dest}=req.body||{};
 if(typeof dest!=="string"||dest.length<5||dest.length>120)return res.status(400).json({ok:false});
 const k=norm(dest);
 if(action==="envoyer"){
  const o=otps.get(k);if(o&&Date.now()-o.sent<30000)return res.status(429).json({ok:false});
  const code=gen();otps.set(k,{hash:sha(code),exp:Date.now()+6e5,tries:0,sent:Date.now()});
  try{
   if(MODE_TEST==="true")console.log(`[TEST] code pour ${k} : ${code}`);
   else if(canal==="email")await mail(dest,"Votre code de confirmation",`Votre code Agence Mitantsoa : ${code} (valable 10 minutes).`);
   else await sms(k,`Agence Mitantsoa : votre code de confirmation est ${code} (valable 10 min).`);
  }catch(e){console.error("Envoi du code :",e.message);return res.status(502).json({ok:false})}
  return res.json({ok:true});
 }
 if(action==="verifier"){
  const o=otps.get(k),c=String(req.body.code||"").toUpperCase();
  if(!o||Date.now()>o.exp||++o.tries>5){otps.delete(k);return res.json({ok:false})}
  if(sha(c)!==o.hash)return res.json({ok:false});
  otps.delete(k);verified.set(k,Date.now());return res.json({ok:true});
 }
 res.status(400).json({ok:false});
});
// une demande n'est acceptée que si le téléphone ou l'e-mail a été vérifié depuis moins de 2 h
const isVerified=d=>[d&&d.tel,d&&d.email].filter(Boolean).some(x=>{const t=verified.get(norm(x));return t&&Date.now()-t<2*3600e3});

/* ---------- 2. Demandes et registre ---------- */
const REF=/^DEM-\d{8}-[A-Z0-9]{4}$/;
const dossierDir=ref=>{const d=path.join(DATA,"dossiers",ref);fs.mkdirSync(d,{recursive:true});return d};
const ajouter=(d,statut)=>{const r=d.demande||{};
 fs.appendFileSync(REG,JSON.stringify({ref:d.reference,date:new Date().toISOString(),nom:d.nom,prenom:d.prenom,email:d.email,tel:d.tel,pole:r.pole,aide:r.aide,statut})+"\n")};
app.post("/enreg",lim(30),(req,res)=>{
 const d=req.body;if(!d||!REF.test(d.reference||"")||!isVerified(d))return res.status(403).json({ok:false});
 fs.writeFileSync(path.join(dossierDir(d.reference),d.reference+"_donnees.json"),JSON.stringify(d,null,1));
 ajouter(d,"Fiche reçue");res.json({ok:true});
});

/* ---------- 3. Dossier complet (fiche, lettre, pièces) ---------- */
const up=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1048576,files:25}});
const NOM=/^(DEM-\d{8}-[A-Z0-9]{4})_\d{2}(?:-\d{2})?_[A-Za-z0-9-]{1,40}\.(pdf|png|jpg|html)$/;
const MAGIC={pdf:[0x25,0x50,0x44,0x46],png:[0x89,0x50,0x4e,0x47],jpg:[0xff,0xd8,0xff]};
const fichierOk=(f,ref)=>{const m=NOM.exec(f.originalname);if(!m||m[1]!==ref)return false;return m[2]==="html"||MAGIC[m[2]].every((b,i)=>f.buffer[i]===b)};
app.post("/dossier",lim(30),up.fields([{name:"fiche",maxCount:1},{name:"lettre",maxCount:1},{name:"pieces",maxCount:20}]),(req,res)=>{
 try{
  const ref=req.body.reference,d=JSON.parse(req.body.donnees||"{}");
  if(!REF.test(ref||"")||d.reference!==ref||!isVerified(d))return res.status(403).json({ok:false});
  const fichiers=Object.values(req.files||{}).flat();
  if(fichiers.some(f=>!fichierOk(f,ref)))return res.status(400).json({ok:false,erreur:"fichier refusé"});
  const dir=dossierDir(ref);
  fichiers.forEach(f=>fs.writeFileSync(path.join(dir,f.originalname),f.buffer));
  fs.writeFileSync(path.join(dir,ref+"_donnees.json"),JSON.stringify(d,null,1));
  ajouter(d,"Dossier complet");
  if(NOTIF_EMAIL&&tr)mail(NOTIF_EMAIL,"Nouveau dossier "+ref,`Dossier ${ref} reçu (${fichiers.length} fichiers) : ${d.prenom||""} ${d.nom||""} - ${(d.demande||{}).aide||""}`).catch(e=>console.error(e.message));
  res.json({ok:true});
 }catch(e){console.error(e.message);res.status(500).json({ok:false})}
});

/* ---------- 4. Registre Excel (protégé par mot de passe) ---------- */
const eq=(a,b)=>crypto.timingSafeEqual(Buffer.from(sha(a||"")),Buffer.from(sha(b||"")));
const auth=(req,res,next)=>{
 if(!ADMIN_USER||!ADMIN_PASS)return res.status(503).send("Accès admin non configuré");
 const [u,...p]=Buffer.from((req.headers.authorization||"").split(" ")[1]||"","base64").toString().split(":");
 if(eq(u,ADMIN_USER)&&eq(p.join(":"),ADMIN_PASS))return next();
 res.set("WWW-Authenticate",'Basic realm="Registre"').status(401).send("Accès refusé");
};
app.get("/admin/registre.xlsx",lim(30),auth,async(req,res)=>{
 const l=fs.existsSync(REG)?fs.readFileSync(REG,"utf8").split("\n").filter(Boolean).map(x=>JSON.parse(x)):[];
 const m=new Map();l.forEach(x=>m.set(x.ref,{...(m.get(x.ref)||{}),...x,date:(m.get(x.ref)||x).date}));
 const wb=new ExcelJS.Workbook(),ws=wb.addWorksheet("Registre");
 ws.columns=[{header:"N°",key:"n",width:6},{header:"Numéro de signature",key:"ref",width:26},{header:"Date",key:"d",width:13},{header:"Heure",key:"h",width:9},
  {header:"Nom",key:"nom",width:20},{header:"Prénom",key:"prenom",width:20},{header:"E-mail",key:"email",width:28},{header:"Téléphone",key:"tel",width:16},
  {header:"Pôle",key:"pole",width:30},{header:"Aide demandée",key:"aide",width:26},{header:"Statut",key:"statut",width:18}];
 [...m.values()].forEach((x,i)=>{const t=new Date(x.date);ws.addRow({n:i+1,...x,d:t.toLocaleDateString("fr-FR"),h:t.toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"})})});
 const b={style:"thin",color:{argb:"FF999999"}};
 ws.eachRow(r=>r.eachCell(c=>{c.border={top:b,left:b,bottom:b,right:b}}));
 const h=ws.getRow(1);h.height=26;h.eachCell(c=>{c.font={bold:true,color:{argb:"FFFFFFFF"},size:12};c.fill={type:"pattern",pattern:"solid",fgColor:{argb:"FF24463B"}};c.alignment={vertical:"middle",horizontal:"center",wrapText:true}});
 ws.views=[{state:"frozen",ySplit:1}];ws.autoFilter={from:"A1",to:"K1"};
 res.set({"Content-Type":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Content-Disposition":'attachment; filename="Registre_Signatures_Mitantsoa.xlsx"'});
 await wb.xlsx.write(res);res.end();
});

app.get("/",(q,r)=>r.send("Serveur Agence Mitantsoa : en ligne"));
app.listen(PORT,HOST,()=>console.log(`Serveur Mitantsoa sur http://${HOST}:${PORT} (MODE_TEST=${MODE_TEST})`));
